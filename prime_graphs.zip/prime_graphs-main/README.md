# prime_graphs
some code for what we did it the paper
